
<!doctype html>
<html lang="en">


<head>
	<title>Admin </title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap 5 admin dashboard template & web App ui kit.">
	<meta name="keyword" content="bootstrap admin template">

	<!--[ Favicon]-->
	<link rel="icon" type="image/x-icon" href="<?php echo e(asset('backend/assets/images/favicon.ico')); ?>">
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('backend/assets/images/favicon-16x16.png')); ?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('backend/assets/images/favicon-32x32.png')); ?>">
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('backend/assets/images/apple-touch-icon.png')); ?>">
	<link href="<?php echo e(asset('all/css/style.css')); ?>" rel="stylesheet" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/dataTables.min.css')); ?>">


	<!--[ Template main css file ]-->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/prism.min.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/style.min.css')); ?>">

</head>

<body data-bvite="theme-CeruleanBlue" class="layout-border svgstroke-a layout-default rightbar-hide">

	<!-- start: main grid layout -->
	<main class="container-fluid px-0">

		<!-- start: project logo -->
		<div class="px-md-4 px-2 pt-2 pb-2 brand" data-bs-theme="none">
		    	<div>
				<div class="d-flex align-items-center pt-1">
					<button class="btn d-inline-flex d-xl-none border-0 p-0 pe-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvas_Navbar">
						<svg class="svg-stroke" xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							<path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							<path d="M4 6l16 0"></path>
							<path d="M4 12l16 0"></path>
							<path d="M4 18l16 0" ></path>
						</svg>
					</button>
				</div>
			</div>
			<div>
				<div class="d-flex align-items-center pt-1">
					<button class="btn d-inline-flex d-xl-none border-0 p-0 pe-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvas_Navbar">

					</button>
					<!--[ Start:: Brand Logo icon ]-->
					
				</div>

			</div>

		</div>

		<!-- start: page header -->
		<header class="px-md-4 px-2" data-bs-theme="none">
			<div class="d-flex justify-content-between align-items-center py-2 w-100">
				


				

				<ul class="header-menu flex-grow-1">
					<!--[ Start:: notification ]-->
					
					
					<!--[ Start:: language ]-->
					
					<!--[ Start:: theme light/dark ]-->
					
					<!--[ Start:: theme setting ]-->
					
					
					<!--[ Start:: user detail ]-->
					
				</ul>
			</div>
		</header>

		<!-- start: page menu link -->
		<aside class="ps-4 pe-3 py-3 sidebar" data-bs-theme="none">
			<nav class="navbar navbar-expand-xl py-0">
				<div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="offcanvas_Navbar">
					<!--<div class="offcanvas-header">-->
					<!--	<div class="d-flex">-->
							<!--<a href="index-2.html" class="brand-icon me-2">-->
							<!--	<svg height="26" viewBox="0 0 40 32" fill="none" xmlns="http://www.w3.org/2000/svg">-->
							<!--		<path fill="var(--primary-color)" fill-rule="evenodd" clip-rule="evenodd" d="M8.30814 0C6.02576 0 4.33695 1.99763 4.41254 4.16407C4.48508 6.24542 4.39085 8.94102 3.7122 11.1393C3.03153 13.3441 1.88034 14.7407 0 14.92V16.9444C1.88034 17.1237 3.03153 18.5203 3.7122 20.7251C4.39085 22.9234 4.48508 25.619 4.41254 27.7003C4.33695 29.8664 6.02576 31.8644 8.30847 31.8644H31.6949C33.9773 31.8644 35.6658 29.8668 35.5902 27.7003C35.5176 25.619 35.6119 22.9234 36.2905 20.7251C36.9715 18.5203 38.1197 17.1237 40 16.9444V14.92C38.1197 14.7407 36.9715 13.3441 36.2905 11.1393C35.6119 8.94136 35.5176 6.24542 35.5902 4.16407C35.6658 1.99797 33.9773 0 31.6949 0H8.30814Z"/>-->
							<!--		<path fill="white" d="M30.0474 8.81267L20.0721 26.7214C19.8661 27.0911 19.337 27.0933 19.128 26.7253L8.95492 8.81436C8.72711 8.41342 9.06866 7.92768 9.52124 8.009L19.5072 9.80102C19.5709 9.81245 19.6361 9.81234 19.6998 9.80069L29.4769 8.01156C29.928 7.92899 30.2711 8.41086 30.0474 8.81267Z"/>-->
							<!--		<path fill="var(--primary-color)" d="M22.9634 11.0029L18.4147 11.8178C18.3784 11.8243 18.3455 11.8417 18.3211 11.8672C18.2967 11.8927 18.2823 11.9248 18.2801 11.9586L18.0003 16.2791C17.9937 16.3808 18.0959 16.4598 18.2046 16.4369L19.471 16.1697C19.5895 16.1447 19.6966 16.2401 19.6722 16.3491L19.2959 18.0335C19.2706 18.1468 19.387 18.2438 19.5081 18.2101L20.2903 17.9929C20.4116 17.9592 20.5281 18.0564 20.5025 18.1699L19.9045 20.8157C19.8671 20.9812 20.1079 21.0715 20.2083 20.9296L20.2754 20.8348L23.9819 14.0722C24.044 13.959 23.937 13.8299 23.8009 13.8539L22.4974 14.0839C22.3749 14.1055 22.2706 14.0012 22.3052 13.8916L23.156 11.1951C23.1906 11.0854 23.086 10.981 22.9634 11.0029Z"/>-->
							<!--	</svg>-->
							<!--</a>-->
					<!--	</div>-->
					<!--	<button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>-->
					<!--</div>-->
					<div class="offcanvas-body flex-column custom_scroll ps-4 ps-xl-0">
						<!-- start: Workspace -->
						<h6 class="fl-title title-font ps-2 small text-uppercase text-muted" style="--text-color: var(--theme-color1)"></h6>
						<ul class="list-unstyled mb-4 menu-list">
							<li>
								<a href="/admin/dashboard" aria-label="My Dashboard">

									<span class="mx-2">Dashboard</span>
								</a>
							</li>
							<li>
								<a href="/admin/gallery" >

									<span class="mx-2">Gallery </span>
								</a>
							</li>
                            <li>
								<a href="/admin/achievement" >

									<span class="mx-2">Achivement </span>
								</a>
							</li>
							<li>
								<a href="/admin/awards" >

									<span class="mx-2">Awards </span>
								</a>
							</li>
							<form method="POST" action="<?php echo e(route('logout')); ?>">
								<?php echo csrf_field(); ?>
								<li><button type="submit" class="btn btn-danger" onclick="return confirm('Do you want to logout ?')"> Log out</button></li>
							</form>
							
						</ul>

					</div>

				</div>
			</nav>
		</aside>
		<!-- start: page header area -->







        <?php echo $__env->yieldContent("body"); ?>









		<!-- start: page footer -->
		<footer class="px-md-4 px-2">
			<p class="mb-0 text-muted">Design and developed by <a href="https://cyenosure.com/" target="_blank">Cyenosure</a></p>
		</footer>

	</main>


	<!-- Template page js -->
	<script src="<?php echo e(asset('backend/assets/js/main.js')); ?>"></script>
	<script src="<?php echo e(asset('all/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('all/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('all/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('all/summernote1.js')); ?>"></script>
    <script src="<?php echo e(asset('all/summernote.js')); ?>"></script>
	
	<script src="<?php echo e(asset('backend/assets/bundles/prism.bundle.js')); ?>"></script>


	<script>
		jQuery(function () {

			// Revenue and Cost
			initApexChart(document.querySelector("#apex-MyAnalytics"), {
				series: [{
					name: 'Revenue',
					data: [13, 23, 20, 8, 13, 27, 33, 12, 67, 22, 43, 21,]
				}, {
					name: 'Cost',
					data: [44, 55, 41, 67, 22, 43, 21, 49, 13, 23, 20, 8,]
				}],
				chart: {
					type: 'bar',
					height: 240,
					stacked: true,
					//stackType: '100%',
					toolbar: {
						show: false,
					},
				},
				colors: ['var(--theme-color1)', 'var(--accent-color)'],
				responsive: [{
					breakpoint: 480,
					options: {
						legend: {
							position: 'bottom',
							offsetX: -10,
							offsetY: 0
						}
					}
				}],
				xaxis: {
					categories: ['Jan', 'Feb', 'Marc', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'],
				},
				yaxis: {
					labels: {
						style: {
							colors: ['#ffffff'],
						}
					}
				},
				fill: {
					opacity: 1
				},
				dataLabels: {
					enabled: false,
				},
				legend: {
					position: 'bottom',
				},
				tooltip: {
					y: [{
						title: {
							formatter: function (val) {
								return val + " (K)"
							}
						}
					}, {
						title: {
							formatter: function (val) {
								return val + " (K)"
							}
						}
					}]
				},
			});

			// Sales Analytics
			initApexChart(document.querySelector("#apex-SalesAnalytics"), {
				series: [{
					name: 'Mobile',
					data: [31, 40, 28, 51, 42, 109, 100, 40, 28, 51, 42, 22]
				}, {
					name: 'Web',
					data: [11, 32, 42, 109, 100, 40, 28, 45, 32, 34, 52, 41]
				}],
				chart: {
					height: 270,
					type: 'area',
					toolbar: {
						show: false,
					}
				},
				colors: ['var(--theme-color2)', 'var(--theme-color5)'],
				fill: {
					type: "gradient",
					gradient: {
						//shade: "dark",
						//type: "horizontal",
						shadeIntensity: 0.5,
						gradientToColors: ['var(--theme-color2)', 'var(--theme-color5)'],
						inverseColors: true,
						opacityFrom: 1,
						opacityTo: 0.3,
						stops: [0, 100]
					}
				},
				dataLabels: {
					enabled: false
				},
				stroke: {
					curve: 'smooth',
					width: 1,
				},
				xaxis: {
					categories: ["Jan", "Feb", "March", "April", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec",]
				},
			});

			// Team Performance
			initApexChart(document.querySelector("#apex-TeamPerformance"), {
				chart: {
					height: 240,
					type: "radialBar",
				},
				series: [67],
				colors: ["var(--theme-color1)"],
				plotOptions: {
					radialBar: {
						startAngle: -90,
						endAngle: 90,
						track: {
							background: 'var(--bs-border-color)',
							startAngle: -90,
							endAngle: 90,
						},
						dataLabels: {
							name: {
								show: false,
							},
							value: {
								fontSize: "30px",
								show: true
							}
						}
					}
				},
				fill: {
					type: "gradient",
					gradient: {
						shade: "dark",
						type: "horizontal",
						gradientToColors: ["var(--theme-color3)"],
						stops: [0, 100]
					}
				},
				stroke: {
					lineCap: "butt"
				},
				labels: ["Progress"]
			});

			initApexChart(document.querySelector("#apex-EmployeeSalary"), {
				series: [{
					data: [400, 430, 448, 690, 1100, 1200, 1380]
				}],
				colors: ["var(--theme-color1)"],
				chart: {
					type: 'bar',
					height: 256,
					toolbar: {
						show: false,
					},
				},
				plotOptions: {
					bar: {
						borderRadius: 4,
						horizontal: true,
					}
				},
				dataLabels: {
					enabled: false
				},
				xaxis: {
					categories: ['Design', 'Developer', 'Marketing', 'SOE', 'BD', 'HR', 'Sales'],
				}
			});
		});


	$(document).ready( function () {
		$('.dataTable')
		.addClass( 'nowrap' )
		.dataTable( {
			responsive: true,
		});
	});


	</script>




</body>


</html>
<?php /**PATH C:\xampp\htdocs\AddWorld\adworld\resources\views/layouts/admin.blade.php ENDPATH**/ ?>