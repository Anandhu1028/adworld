<!DOCTYPE html>
<html lang="en-US" class="no-js no-svg">
<!-- Mirrored from wp.themerange.net/moko/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Mar 2024 09:15:57 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8">
<!-- /Added by HTTrack -->

<head>
	<meta charset="UTF-8">
	<link href="<?php echo e(asset('frontend/themes/moko/assets/images/favicon.png')); ?>" rel="icon" type="image/x-icon">
	<!-- responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- For IE -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Adworld</title>
	<meta name="robots" content="max-image-preview:large">
	<link rel="dns-prefetch" href="http://fonts.googleapis.com/">
	<link rel="alternate" type="application/rss+xml" title="Moko &raquo; Feed" href="feed/index.html">
	<link rel="alternate" type="application/rss+xml" title="Moko &raquo; Comments Feed" href="comments/feed/index.html">
	<script type="text/javascript">
		/* <![CDATA[ */
		window._wpemojiSettings = { "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/", "ext": ".png", "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/", "svgExt": ".svg", "source": { "concatemoji": "https:\/\/wp.themerange.net\/moko\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.4.3" } };
		/*! This file is auto-generated */
		!function (i, n) { var o, s, e; function c(e) { try { var t = { supportTests: e, timestamp: (new Date).valueOf() }; sessionStorage.setItem(o, JSON.stringify(t)) } catch (e) { } } function p(e, t, n) { e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(t, 0, 0); var t = new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data), r = (e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(n, 0, 0), new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data)); return t.every(function (e, t) { return e === r[t] }) } function u(e, t, n) { switch (t) { case "flag": return n(e, "\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f", "\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f") ? !1 : !n(e, "\ud83c\uddfa\ud83c\uddf3", "\ud83c\uddfa\u200b\ud83c\uddf3") && !n(e, "\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f", "\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f"); case "emoji": return !n(e, "\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff", "\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff") }return !1 } function f(e, t, n) { var r = "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? new OffscreenCanvas(300, 150) : i.createElement("canvas"), a = r.getContext("2d", { willReadFrequently: !0 }), o = (a.textBaseline = "top", a.font = "600 32px Arial", {}); return e.forEach(function (e) { o[e] = t(a, e, n) }), o } function t(e) { var t = i.createElement("script"); t.src = e, t.defer = !0, i.head.appendChild(t) } "undefined" != typeof Promise && (o = "wpEmojiSettingsSupports", s = ["flag", "emoji"], n.supports = { everything: !0, everythingExceptFlag: !0 }, e = new Promise(function (e) { i.addEventListener("DOMContentLoaded", e, { once: !0 }) }), new Promise(function (t) { var n = function () { try { var e = JSON.parse(sessionStorage.getItem(o)); if ("object" == typeof e && "number" == typeof e.timestamp && (new Date).valueOf() < e.timestamp + 604800 && "object" == typeof e.supportTests) return e.supportTests } catch (e) { } return null }(); if (!n) { if ("undefined" != typeof Worker && "undefined" != typeof OffscreenCanvas && "undefined" != typeof URL && URL.createObjectURL && "undefined" != typeof Blob) try { var e = "postMessage(" + f.toString() + "(" + [JSON.stringify(s), u.toString(), p.toString()].join(",") + "));", r = new Blob([e], { type: "text/javascript" }), a = new Worker(URL.createObjectURL(r), { name: "wpTestEmojiSupports" }); return void (a.onmessage = function (e) { c(n = e.data), a.terminate(), t(n) }) } catch (e) { } c(n = f(s, u, p)) } t(n) }).then(function (e) { for (var t in e) n.supports[t] = e[t], n.supports.everything = n.supports.everything && n.supports[t], "flag" !== t && (n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && n.supports[t]); n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && !n.supports.flag, n.DOMReady = !1, n.readyCallback = function () { n.DOMReady = !0 } }).then(function () { return e }).then(function () { var e; n.supports.everything || (n.readyCallback(), (e = n.source || {}).concatemoji ? t(e.concatemoji) : e.wpemoji && e.twemoji && (t(e.twemoji), t(e.wpemoji))) })) }((window, document), window._wpemojiSettings);
		/* ]]> */
	</script>
	<style id="wp-emoji-styles-inline-css" type="text/css">
		img.wp-smiley,
		img.emoji {
			display: inline !important;
			border: none !important;
			box-shadow: none !important;
			height: 1em !important;
			width: 1em !important;
			margin: 0 0.07em !important;
			vertical-align: -0.1em !important;
			background: none !important;
			padding: 0 !important;
		}
	</style>
	<link rel="stylesheet" id="wp-block-library-css" href="<?php echo e(asset('frontend/css/dist/block-library/style.min84fc.css?ver=6.4.3')); ?>" type="text/css" media="all">
	<style id="wp-block-library-theme-inline-css" type="text/css">
		.wp-block-audio figcaption {
			color: #555;
			font-size: 13px;
			text-align: center
		}

		.is-dark-theme .wp-block-audio figcaption {
			color: hsla(0, 0%, 100%, .65)
		}

		.wp-block-audio {
			margin: 0 0 1em
		}

		.wp-block-code {
			border: 1px solid #ccc;
			border-radius: 4px;
			font-family: Menlo, Consolas, monaco, monospace;
			padding: .8em 1em
		}

		.wp-block-embed figcaption {
			color: #555;
			font-size: 13px;
			text-align: center
		}

		.is-dark-theme .wp-block-embed figcaption {
			color: hsla(0, 0%, 100%, .65)
		}

		.wp-block-embed {
			margin: 0 0 1em
		}

		.blocks-gallery-caption {
			color: #555;
			font-size: 13px;
			text-align: center
		}

		.is-dark-theme .blocks-gallery-caption {
			color: hsla(0, 0%, 100%, .65)
		}

		.wp-block-image figcaption {
			color: #555;
			font-size: 13px;
			text-align: center
		}

		.is-dark-theme .wp-block-image figcaption {
			color: hsla(0, 0%, 100%, .65)
		}

		.wp-block-image {
			margin: 0 0 1em
		}

		.wp-block-pullquote {
			border-bottom: 4px solid;
			border-top: 4px solid;
			color: currentColor;
			margin-bottom: 1.75em
		}

		.wp-block-pullquote cite,
		.wp-block-pullquote footer,
		.wp-block-pullquote__citation {
			color: currentColor;
			font-size: .8125em;
			font-style: normal;
			text-transform: uppercase
		}

		.wp-block-quote {
			border-left: .25em solid;
			margin: 0 0 1.75em;
			padding-left: 1em
		}

		.wp-block-quote cite,
		.wp-block-quote footer {
			color: currentColor;
			font-size: .8125em;
			font-style: normal;
			position: relative
		}

		.wp-block-quote.has-text-align-right {
			border-left: none;
			border-right: .25em solid;
			padding-left: 0;
			padding-right: 1em
		}

		.wp-block-quote.has-text-align-center {
			border: none;
			padding-left: 0
		}

		.wp-block-quote.is-large,
		.wp-block-quote.is-style-large,
		.wp-block-quote.is-style-plain {
			border: none
		}

		.wp-block-search .wp-block-search__label {
			font-weight: 700
		}

		.wp-block-search__button {
			border: 1px solid #ccc;
			padding: .375em .625em
		}

		:where(.wp-block-group.has-background) {
			padding: 1.25em 2.375em
		}

		.wp-block-separator.has-css-opacity {
			opacity: .4
		}

		.wp-block-separator {
			border: none;
			border-bottom: 2px solid;
			margin-left: auto;
			margin-right: auto
		}

		.wp-block-separator.has-alpha-channel-opacity {
			opacity: 1
		}

		.wp-block-separator:not(.is-style-wide):not(.is-style-dots) {
			width: 100px
		}

		.wp-block-separator.has-background:not(.is-style-dots) {
			border-bottom: none;
			height: 1px
		}

		.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots) {
			height: 2px
		}

		.wp-block-table {
			margin: 0 0 1em
		}

		.wp-block-table td,
		.wp-block-table th {
			word-break: normal
		}

		.wp-block-table figcaption {
			color: #555;
			font-size: 13px;
			text-align: center
		}

		.is-dark-theme .wp-block-table figcaption {
			color: hsla(0, 0%, 100%, .65)
		}

		.wp-block-video figcaption {
			color: #555;
			font-size: 13px;
			text-align: center
		}

		.is-dark-theme .wp-block-video figcaption {
			color: hsla(0, 0%, 100%, .65)
		}

		.wp-block-video {
			margin: 0 0 1em
		}

		.wp-block-template-part.has-background {
			margin-bottom: 0;
			margin-top: 0;
			padding: 1.25em 2.375em
		}
	</style>
	<style id="classic-theme-styles-inline-css" type="text/css">
		/*! This file is auto-generated */
		.wp-block-button__link {
			color: #fff;
			background-color: #32373c;
			border-radius: 9999px;
			box-shadow: none;
			text-decoration: none;
			padding: calc(.667em + 2px) calc(1.333em + 2px);
			font-size: 1.125em
		}

		.wp-block-file__button {
			background: #32373c;
			color: #fff;
			text-decoration: none
		}
	</style>
	<style id="global-styles-inline-css" type="text/css">
		body {
			--wp--preset--color--black: #000000;
			--wp--preset--color--cyan-bluish-gray: #abb8c3;
			--wp--preset--color--white: #ffffff;
			--wp--preset--color--pale-pink: #f78da7;
			--wp--preset--color--vivid-red: #cf2e2e;
			--wp--preset--color--luminous-vivid-orange: #ff6900;
			--wp--preset--color--luminous-vivid-amber: #fcb900;
			--wp--preset--color--light-green-cyan: #7bdcb5;
			--wp--preset--color--vivid-green-cyan: #00d084;
			--wp--preset--color--pale-cyan-blue: #8ed1fc;
			--wp--preset--color--vivid-cyan-blue: #0693e3;
			--wp--preset--color--vivid-purple: #9b51e0;
			--wp--preset--color--strong-yellow: #f7bd00;
			--wp--preset--color--strong-white: #fff;
			--wp--preset--color--light-black: #242424;
			--wp--preset--color--very-light-gray: #797979;
			--wp--preset--color--very-dark-black: #000000;
			--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
			--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
			--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
			--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
			--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
			--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
			--wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
			--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
			--wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
			--wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
			--wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
			--wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
			--wp--preset--font-size--small: 10px;
			--wp--preset--font-size--medium: 20px;
			--wp--preset--font-size--large: 24px;
			--wp--preset--font-size--x-large: 42px;
			--wp--preset--font-size--normal: 15px;
			--wp--preset--font-size--huge: 36px;
			--wp--preset--spacing--20: 0.44rem;
			--wp--preset--spacing--30: 0.67rem;
			--wp--preset--spacing--40: 1rem;
			--wp--preset--spacing--50: 1.5rem;
			--wp--preset--spacing--60: 2.25rem;
			--wp--preset--spacing--70: 3.38rem;
			--wp--preset--spacing--80: 5.06rem;
			--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
			--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
			--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
			--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
			--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
		}

		:where(.is-layout-flex) {
			gap: 0.5em;
		}

		:where(.is-layout-grid) {
			gap: 0.5em;
		}

		body .is-layout-flow>.alignleft {
			float: left;
			margin-inline-start: 0;
			margin-inline-end: 2em;
		}

		body .is-layout-flow>.alignright {
			float: right;
			margin-inline-start: 2em;
			margin-inline-end: 0;
		}

		body .is-layout-flow>.aligncenter {
			margin-left: auto !important;
			margin-right: auto !important;
		}

		body .is-layout-constrained>.alignleft {
			float: left;
			margin-inline-start: 0;
			margin-inline-end: 2em;
		}

		body .is-layout-constrained>.alignright {
			float: right;
			margin-inline-start: 2em;
			margin-inline-end: 0;
		}

		body .is-layout-constrained>.aligncenter {
			margin-left: auto !important;
			margin-right: auto !important;
		}

		body .is-layout-constrained> :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
			max-width: var(--wp--style--global--content-size);
			margin-left: auto !important;
			margin-right: auto !important;
		}

		body .is-layout-constrained>.alignwide {
			max-width: var(--wp--style--global--wide-size);
		}

		body .is-layout-flex {
			display: flex;
		}

		body .is-layout-flex {
			flex-wrap: wrap;
			align-items: center;
		}

		body .is-layout-flex>* {
			margin: 0;
		}

		body .is-layout-grid {
			display: grid;
		}

		body .is-layout-grid>* {
			margin: 0;
		}

		:where(.wp-block-columns.is-layout-flex) {
			gap: 2em;
		}

		:where(.wp-block-columns.is-layout-grid) {
			gap: 2em;
		}

		:where(.wp-block-post-template.is-layout-flex) {
			gap: 1.25em;
		}

		:where(.wp-block-post-template.is-layout-grid) {
			gap: 1.25em;
		}

		.has-black-color {
			color: var(--wp--preset--color--black) !important;
		}

		.has-cyan-bluish-gray-color {
			color: var(--wp--preset--color--cyan-bluish-gray) !important;
		}

		.has-white-color {
			color: var(--wp--preset--color--white) !important;
		}

		.has-pale-pink-color {
			color: var(--wp--preset--color--pale-pink) !important;
		}

		.has-vivid-red-color {
			color: var(--wp--preset--color--vivid-red) !important;
		}

		.has-luminous-vivid-orange-color {
			color: var(--wp--preset--color--luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-amber-color {
			color: var(--wp--preset--color--luminous-vivid-amber) !important;
		}

		.has-light-green-cyan-color {
			color: var(--wp--preset--color--light-green-cyan) !important;
		}

		.has-vivid-green-cyan-color {
			color: var(--wp--preset--color--vivid-green-cyan) !important;
		}

		.has-pale-cyan-blue-color {
			color: var(--wp--preset--color--pale-cyan-blue) !important;
		}

		.has-vivid-cyan-blue-color {
			color: var(--wp--preset--color--vivid-cyan-blue) !important;
		}

		.has-vivid-purple-color {
			color: var(--wp--preset--color--vivid-purple) !important;
		}

		.has-black-background-color {
			background-color: var(--wp--preset--color--black) !important;
		}

		.has-cyan-bluish-gray-background-color {
			background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
		}

		.has-white-background-color {
			background-color: var(--wp--preset--color--white) !important;
		}

		.has-pale-pink-background-color {
			background-color: var(--wp--preset--color--pale-pink) !important;
		}

		.has-vivid-red-background-color {
			background-color: var(--wp--preset--color--vivid-red) !important;
		}

		.has-luminous-vivid-orange-background-color {
			background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-amber-background-color {
			background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
		}

		.has-light-green-cyan-background-color {
			background-color: var(--wp--preset--color--light-green-cyan) !important;
		}

		.has-vivid-green-cyan-background-color {
			background-color: var(--wp--preset--color--vivid-green-cyan) !important;
		}

		.has-pale-cyan-blue-background-color {
			background-color: var(--wp--preset--color--pale-cyan-blue) !important;
		}

		.has-vivid-cyan-blue-background-color {
			background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
		}

		.has-vivid-purple-background-color {
			background-color: var(--wp--preset--color--vivid-purple) !important;
		}

		.has-black-border-color {
			border-color: var(--wp--preset--color--black) !important;
		}

		.has-cyan-bluish-gray-border-color {
			border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
		}

		.has-white-border-color {
			border-color: var(--wp--preset--color--white) !important;
		}

		.has-pale-pink-border-color {
			border-color: var(--wp--preset--color--pale-pink) !important;
		}

		.has-vivid-red-border-color {
			border-color: var(--wp--preset--color--vivid-red) !important;
		}

		.has-luminous-vivid-orange-border-color {
			border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-amber-border-color {
			border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
		}

		.has-light-green-cyan-border-color {
			border-color: var(--wp--preset--color--light-green-cyan) !important;
		}

		.has-vivid-green-cyan-border-color {
			border-color: var(--wp--preset--color--vivid-green-cyan) !important;
		}

		.has-pale-cyan-blue-border-color {
			border-color: var(--wp--preset--color--pale-cyan-blue) !important;
		}

		.has-vivid-cyan-blue-border-color {
			border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
		}

		.has-vivid-purple-border-color {
			border-color: var(--wp--preset--color--vivid-purple) !important;
		}

		.has-vivid-cyan-blue-to-vivid-purple-gradient-background {
			background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
		}

		.has-light-green-cyan-to-vivid-green-cyan-gradient-background {
			background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
		}

		.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
			background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-orange-to-vivid-red-gradient-background {
			background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
		}

		.has-very-light-gray-to-cyan-bluish-gray-gradient-background {
			background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
		}

		.has-cool-to-warm-spectrum-gradient-background {
			background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
		}

		.has-blush-light-purple-gradient-background {
			background: var(--wp--preset--gradient--blush-light-purple) !important;
		}

		.has-blush-bordeaux-gradient-background {
			background: var(--wp--preset--gradient--blush-bordeaux) !important;
		}

		.has-luminous-dusk-gradient-background {
			background: var(--wp--preset--gradient--luminous-dusk) !important;
		}

		.has-pale-ocean-gradient-background {
			background: var(--wp--preset--gradient--pale-ocean) !important;
		}

		.has-electric-grass-gradient-background {
			background: var(--wp--preset--gradient--electric-grass) !important;
		}

		.has-midnight-gradient-background {
			background: var(--wp--preset--gradient--midnight) !important;
		}

		.has-small-font-size {
			font-size: var(--wp--preset--font-size--small) !important;
		}

		.has-medium-font-size {
			font-size: var(--wp--preset--font-size--medium) !important;
		}

		.has-large-font-size {
			font-size: var(--wp--preset--font-size--large) !important;
		}

		.has-x-large-font-size {
			font-size: var(--wp--preset--font-size--x-large) !important;
		}

		.wp-block-navigation a:where(:not(.wp-element-button)) {
			color: inherit;
		}

		:where(.wp-block-post-template.is-layout-flex) {
			gap: 1.25em;
		}

		:where(.wp-block-post-template.is-layout-grid) {
			gap: 1.25em;
		}

		:where(.wp-block-columns.is-layout-flex) {
			gap: 2em;
		}

		:where(.wp-block-columns.is-layout-grid) {
			gap: 2em;
		}

		.wp-block-pullquote {
			font-size: 1.5em;
			line-height: 1.6;
		}
	</style>
	
	<link rel="stylesheet" id="woocommerce-layout-css"
		href="<?php echo e(asset('frontend/plugins/woocommerce/assets/css/woocommerce-layout9662.css?ver=8.3.0')); ?>" type="text/css"
		media="all">
	<link rel="stylesheet" id="woocommerce-smallscreen-css"
		href="<?php echo e(asset('frontend/plugins/woocommerce/assets/css/woocommerce-smallscreen9662.css?ver=8.3.0')); ?>" type="text/css"
		media="only screen and (max-width: 768px)">
	<link rel="stylesheet" id="woocommerce-general-css"
		href="<?php echo e(asset('frontend/plugins/woocommerce/assets/css/woocommerce9662.css?ver=8.3.0')); ?>" type="text/css" media="all">
	<style id="woocommerce-inline-inline-css" type="text/css">
		.woocommerce form .form-row .required {
			visibility: visible;
		}
	</style>
	<link rel="stylesheet" id="bootstrap-css" href="<?php echo e(asset('frontend/themes/moko/assets/css/bootstrap84fc.css?ver=6.4.3')); ?>"
		type="text/css" media="all">
	<link rel="stylesheet" id="fontawesome-all-css"
		href="<?php echo e(asset('frontend/themes/moko/assets/css/fontawesome-all84fc.css?ver=6.4.3')); ?>" type="text/css" media="all">
	<link rel="stylesheet" id="flaticon-css" href="<?php echo e(asset('frontend/themes/moko/assets/css/flaticon84fc.css?ver=6.4.3')); ?>"
		type="text/css" media="all">
	<link rel="stylesheet" id="animate-css" href="<?php echo e(asset('frontend/themes/moko/assets/css/animate84fc.css?ver=6.4.3')); ?>"
		type="text/css" media="all">
	<link rel="stylesheet" id="owl-css" href="<?php echo e(asset('frontend/themes/moko/assets/css/owl84fc.css?ver=6.4.3" type="text/css')); ?>"
		media="all">
	<link rel="stylesheet" id="animation-css" href="<?php echo e(asset('frontend/themes/moko/assets/css/animation84fc.css?ver=6.4.3')); ?>"
		type="text/css" media="all">
	<link rel="stylesheet" id="jquery-ui-css" href="<?php echo e(asset('frontend/themes/moko/assets/css/jquery-ui84fc.css?ver=6.4.3')); ?>"
		type="text/css" media="all">
	<link rel="stylesheet" id="custom-animate-css"
		href="<?php echo e(asset('frontend/themes/moko/assets/css/custom-animate84fc.css?ver=6.4.3')); ?>" type="text/css" media="all">
	<link rel="stylesheet" id="magnific-popup-css"
		href="<?php echo e(asset('frontend/themes/moko/assets/css/jquery.fancybox.min84fc.css?ver=6.4.3')); ?>" type="text/css" media="all">
	<link rel="stylesheet" id="bootstrap-touchspin-css"
		href="<?php echo e(asset('frontend/themes/moko/assets/css/jquery.bootstrap-touchspin84fc.css?ver=6.4.3')); ?>" type="text/css"
		media="all">
	<link rel="stylesheet" id="mCustomScrollbar-css"
		href="<?php echo e(asset('frontend/themes/moko/assets/css/jquery.mCustomScrollbar.min84fc.css?ver=6.4.3')); ?>" type="text/css"
		media="all">
	<link rel="stylesheet" id="moko-main-css" href="<?php echo e(asset('frontend/themes/moko/style84fc.css?ver=6.4.3')); ?>" type="text/css"
		media="all">
	<link rel="stylesheet" id="moko-style-css" href="<?php echo e(asset('frontend/themes/moko/assets/css/style84fc.css?ver=6.4.3')); ?>"
		type="text/css" media="all">
	<link rel="stylesheet" id="moko-custom-css" href="<?php echo e(asset('frontend/themes/moko/assets/css/custom84fc.css?ver=6.4.3')); ?>"
		type="text/css" media="all">
	<link rel="stylesheet" id="moko-woocommerce-css"
		href="<?php echo e(asset('frontend/themes/moko/assets/css/woocommerce84fc.css?ver=6.4.3')); ?>" type="text/css" media="all">
	<link rel="stylesheet" id="moko-responsive-css"
		href="<?php echo e(asset('frontend/themes/moko/assets/css/responsive84fc.css?ver=6.4.3')); ?>" type="text/css" media="all">
	<link rel="stylesheet" id="moko-theme-fonts-css"
		href="https://fonts.googleapis.com/css?family=Archivo%3Awght%40400%2C500%2C600%2C700%7CPoppins%3Awght%40300%2C400%2C500%2C600%2C700%2C800%2C900&amp;subset=latin%2Clatin-ext"
		type="text/css" media="all">
	<link rel="stylesheet" id="elementor-icons-css"
		href="<?php echo e(asset('frontend/plugins/elementor/assets/lib/eicons/css/elementor-icons.min192d.css?ver=5.23.0')); ?>" type="text/css"
		media="all">
	<link rel="stylesheet" id="elementor-frontend-css"
		href="<?php echo e(asset('frontend/plugins/elementor/assets/css/frontend-lite.min8864.css?ver=3.17.3')); ?>" type="text/css" media="all">
	<style id="elementor-frontend-inline-css" type="text/css">
		.elementor-kit-6 {
			--e-global-color-primary: #6EC1E4;
			--e-global-color-secondary: #54595F;
			--e-global-color-text: #7A7A7A;
			--e-global-color-accent: #61CE70;
			--e-global-typography-primary-font-family: "Roboto";
			--e-global-typography-primary-font-weight: 600;
			--e-global-typography-secondary-font-family: "Roboto Slab";
			--e-global-typography-secondary-font-weight: 400;
			--e-global-typography-text-font-family: "Roboto";
			--e-global-typography-text-font-weight: 400;
			--e-global-typography-accent-font-family: "Roboto";
			--e-global-typography-accent-font-weight: 500;
		}

		.elementor-section.elementor-section-boxed>.elementor-container {
			max-width: 1140px;
		}

		.e-con {
			--container-max-width: 1140px;
		}

		.elementor-widget:not(:last-child) {
			margin-block-end: 20px;
		}

		.elementor-element {
			--widgets-spacing: 20px 20px;
		}

			{}

		h1.entry-title {
			display: var(--page-title-display);
		}

		.elementor-kit-6 e-page-transition {
			background-color: #FFBC7D;
		}

		@media(max-width:1024px) {
			.elementor-section.elementor-section-boxed>.elementor-container {
				max-width: 1024px;
			}

			.e-con {
				--container-max-width: 1024px;
			}
		}

		@media(max-width:767px) {
			.elementor-section.elementor-section-boxed>.elementor-container {
				max-width: 767px;
			}

			.e-con {
				--container-max-width: 767px;
			}
		}

		.elementor-widget-heading .elementor-heading-title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-image .widget-image-caption {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-text-editor {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap {
			background-color: var(--e-global-color-primary);
		}

		.elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap,
		.elementor-widget-text-editor.elementor-drop-cap-view-default .elementor-drop-cap {
			color: var(--e-global-color-primary);
			border-color: var(--e-global-color-primary);
		}

		.elementor-widget-button .elementor-button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-divider {
			--divider-color: var(--e-global-color-secondary);
		}

		.elementor-widget-divider .elementor-divider__text {
			color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-divider.elementor-view-stacked .elementor-icon {
			background-color: var(--e-global-color-secondary);
		}

		.elementor-widget-divider.elementor-view-framed .elementor-icon,
		.elementor-widget-divider.elementor-view-default .elementor-icon {
			color: var(--e-global-color-secondary);
			border-color: var(--e-global-color-secondary);
		}

		.elementor-widget-divider.elementor-view-framed .elementor-icon,
		.elementor-widget-divider.elementor-view-default .elementor-icon svg {
			fill: var(--e-global-color-secondary);
		}

		.elementor-widget-image-box .elementor-image-box-title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-image-box .elementor-image-box-description {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-icon.elementor-view-stacked .elementor-icon {
			background-color: var(--e-global-color-primary);
		}

		.elementor-widget-icon.elementor-view-framed .elementor-icon,
		.elementor-widget-icon.elementor-view-default .elementor-icon {
			color: var(--e-global-color-primary);
			border-color: var(--e-global-color-primary);
		}

		.elementor-widget-icon.elementor-view-framed .elementor-icon,
		.elementor-widget-icon.elementor-view-default .elementor-icon svg {
			fill: var(--e-global-color-primary);
		}

		.elementor-widget-icon-box.elementor-view-stacked .elementor-icon {
			background-color: var(--e-global-color-primary);
		}

		.elementor-widget-icon-box.elementor-view-framed .elementor-icon,
		.elementor-widget-icon-box.elementor-view-default .elementor-icon {
			fill: var(--e-global-color-primary);
			color: var(--e-global-color-primary);
			border-color: var(--e-global-color-primary);
		}

		.elementor-widget-icon-box .elementor-icon-box-title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-icon-box .elementor-icon-box-title,
		.elementor-widget-icon-box .elementor-icon-box-title a {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-icon-box .elementor-icon-box-description {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-star-rating .elementor-star-rating__title {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-image-gallery .gallery-item .gallery-caption {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-icon-list .elementor-icon-list-item:not(:last-child):after {
			border-color: var(--e-global-color-text);
		}

		.elementor-widget-icon-list .elementor-icon-list-icon i {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-icon-list .elementor-icon-list-icon svg {
			fill: var(--e-global-color-primary);
		}

		.elementor-widget-icon-list .elementor-icon-list-item>.elementor-icon-list-text,
		.elementor-widget-icon-list .elementor-icon-list-item>a {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-icon-list .elementor-icon-list-text {
			color: var(--e-global-color-secondary);
		}

		.elementor-widget-counter .elementor-counter-number-wrapper {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-counter .elementor-counter-title {
			color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-progress .elementor-progress-wrapper .elementor-progress-bar {
			background-color: var(--e-global-color-primary);
		}

		.elementor-widget-progress .elementor-title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-testimonial .elementor-testimonial-content {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-testimonial .elementor-testimonial-name {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-testimonial .elementor-testimonial-job {
			color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-tabs .elementor-tab-title,
		.elementor-widget-tabs .elementor-tab-title a {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-tabs .elementor-tab-title.elementor-active,
		.elementor-widget-tabs .elementor-tab-title.elementor-active a {
			color: var(--e-global-color-accent);
		}

		.elementor-widget-tabs .elementor-tab-title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-tabs .elementor-tab-content {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-accordion .elementor-accordion-icon,
		.elementor-widget-accordion .elementor-accordion-title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-accordion .elementor-accordion-icon svg {
			fill: var(--e-global-color-primary);
		}

		.elementor-widget-accordion .elementor-active .elementor-accordion-icon,
		.elementor-widget-accordion .elementor-active .elementor-accordion-title {
			color: var(--e-global-color-accent);
		}

		.elementor-widget-accordion .elementor-active .elementor-accordion-icon svg {
			fill: var(--e-global-color-accent);
		}

		.elementor-widget-accordion .elementor-accordion-title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-accordion .elementor-tab-content {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-toggle .elementor-toggle-title,
		.elementor-widget-toggle .elementor-toggle-icon {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-toggle .elementor-toggle-icon svg {
			fill: var(--e-global-color-primary);
		}

		.elementor-widget-toggle .elementor-tab-title.elementor-active a,
		.elementor-widget-toggle .elementor-tab-title.elementor-active .elementor-toggle-icon {
			color: var(--e-global-color-accent);
		}

		.elementor-widget-toggle .elementor-toggle-title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-toggle .elementor-tab-content {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-alert .elementor-alert-title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-alert .elementor-alert-description {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-text-path {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-theme-site-logo .widget-image-caption {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-theme-site-title .elementor-heading-title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-theme-page-title .elementor-heading-title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-theme-post-title .elementor-heading-title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-theme-post-excerpt .elementor-widget-container {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-theme-post-content {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-theme-post-featured-image .widget-image-caption {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-theme-archive-title .elementor-heading-title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-archive-posts .elementor-post__title,
		.elementor-widget-archive-posts .elementor-post__title a {
			color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-archive-posts .elementor-post__meta-data {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-archive-posts .elementor-post__excerpt p {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-archive-posts .elementor-post__read-more {
			color: var(--e-global-color-accent);
		}

		.elementor-widget-archive-posts a.elementor-post__read-more {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-archive-posts .elementor-post__card .elementor-post__badge {
			background-color: var(--e-global-color-accent);
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-archive-posts .elementor-pagination {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-archive-posts .elementor-button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-archive-posts .e-load-more-message {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-archive-posts .elementor-posts-nothing-found {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-posts .elementor-post__title,
		.elementor-widget-posts .elementor-post__title a {
			color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-posts .elementor-post__meta-data {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-posts .elementor-post__excerpt p {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-posts .elementor-post__read-more {
			color: var(--e-global-color-accent);
		}

		.elementor-widget-posts a.elementor-post__read-more {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-posts .elementor-post__card .elementor-post__badge {
			background-color: var(--e-global-color-accent);
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-posts .elementor-pagination {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-posts .elementor-button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-posts .e-load-more-message {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-portfolio a .elementor-portfolio-item__overlay {
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-portfolio .elementor-portfolio-item__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-portfolio .elementor-portfolio__filter {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-portfolio .elementor-portfolio__filter.elementor-active {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-gallery .elementor-gallery-item__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-gallery .elementor-gallery-item__description {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-gallery {
			--galleries-title-color-normal: var(--e-global-color-primary);
			--galleries-title-color-hover: var(--e-global-color-secondary);
			--galleries-pointer-bg-color-hover: var(--e-global-color-accent);
			--gallery-title-color-active: var(--e-global-color-secondary);
			--galleries-pointer-bg-color-active: var(--e-global-color-accent);
		}

		.elementor-widget-gallery .elementor-gallery-title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-form .elementor-field-group>label,
		.elementor-widget-form .elementor-field-subgroup label {
			color: var(--e-global-color-text);
		}

		.elementor-widget-form .elementor-field-group>label {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-form .elementor-field-type-html {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-form .elementor-field-group .elementor-field {
			color: var(--e-global-color-text);
		}

		.elementor-widget-form .elementor-field-group .elementor-field,
		.elementor-widget-form .elementor-field-subgroup label {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-form .elementor-button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-form .e-form__buttons__wrapper__button-next {
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-form .elementor-button[type="submit"] {
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-form .e-form__buttons__wrapper__button-previous {
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-form .elementor-message {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-form .e-form__indicators__indicator,
		.elementor-widget-form .e-form__indicators__indicator__label {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-form {
			--e-form-steps-indicator-inactive-primary-color: var(--e-global-color-text);
			--e-form-steps-indicator-active-primary-color: var(--e-global-color-accent);
			--e-form-steps-indicator-completed-primary-color: var(--e-global-color-accent);
			--e-form-steps-indicator-progress-color: var(--e-global-color-accent);
			--e-form-steps-indicator-progress-background-color: var(--e-global-color-text);
			--e-form-steps-indicator-progress-meter-color: var(--e-global-color-text);
		}

		.elementor-widget-form .e-form__indicators__indicator__progress__meter {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-login .elementor-field-group>a {
			color: var(--e-global-color-text);
		}

		.elementor-widget-login .elementor-field-group>a:hover {
			color: var(--e-global-color-accent);
		}

		.elementor-widget-login .elementor-form-fields-wrapper label {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-login .elementor-field-group .elementor-field {
			color: var(--e-global-color-text);
		}

		.elementor-widget-login .elementor-field-group .elementor-field,
		.elementor-widget-login .elementor-field-subgroup label {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-login .elementor-button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-login .elementor-widget-container .elementor-login__logged-in-message {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-slides .elementor-slide-heading {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-slides .elementor-slide-description {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-slides .elementor-slide-button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-nav-menu .elementor-nav-menu .elementor-item {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-nav-menu .elementor-nav-menu--main .elementor-item {
			color: var(--e-global-color-text);
			fill: var(--e-global-color-text);
		}

		.elementor-widget-nav-menu .elementor-nav-menu--main .elementor-item:hover,
		.elementor-widget-nav-menu .elementor-nav-menu--main .elementor-item.elementor-item-active,
		.elementor-widget-nav-menu .elementor-nav-menu--main .elementor-item.highlighted,
		.elementor-widget-nav-menu .elementor-nav-menu--main .elementor-item:focus {
			color: var(--e-global-color-accent);
			fill: var(--e-global-color-accent);
		}

		.elementor-widget-nav-menu .elementor-nav-menu--main:not(.e--pointer-framed) .elementor-item:before,
		.elementor-widget-nav-menu .elementor-nav-menu--main:not(.e--pointer-framed) .elementor-item:after {
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-nav-menu .e--pointer-framed .elementor-item:before,
		.elementor-widget-nav-menu .e--pointer-framed .elementor-item:after {
			border-color: var(--e-global-color-accent);
		}

		.elementor-widget-nav-menu {
			--e-nav-menu-divider-color: var(--e-global-color-text);
		}

		.elementor-widget-nav-menu .elementor-nav-menu--dropdown .elementor-item,
		.elementor-widget-nav-menu .elementor-nav-menu--dropdown .elementor-sub-item {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-animated-headline .elementor-headline-dynamic-wrapper path {
			stroke: var(--e-global-color-accent);
		}

		.elementor-widget-animated-headline .elementor-headline-plain-text {
			color: var(--e-global-color-secondary);
		}

		.elementor-widget-animated-headline .elementor-headline {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-animated-headline {
			--dynamic-text-color: var(--e-global-color-secondary);
		}

		.elementor-widget-animated-headline .elementor-headline-dynamic-text {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-hotspot .widget-image-caption {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-hotspot {
			--hotspot-color: var(--e-global-color-primary);
			--hotspot-box-color: var(--e-global-color-secondary);
			--tooltip-color: var(--e-global-color-secondary);
		}

		.elementor-widget-hotspot .e-hotspot__label {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-hotspot .e-hotspot__tooltip {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-price-list .elementor-price-list-header {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-price-list .elementor-price-list-price {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-price-list .elementor-price-list-description {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-price-list .elementor-price-list-separator {
			border-bottom-color: var(--e-global-color-secondary);
		}

		.elementor-widget-price-table {
			--e-price-table-header-background-color: var(--e-global-color-secondary);
		}

		.elementor-widget-price-table .elementor-price-table__heading {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-price-table .elementor-price-table__subheading {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-price-table .elementor-price-table .elementor-price-table__price {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-price-table .elementor-price-table__original-price {
			color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-price-table .elementor-price-table__period {
			color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-price-table .elementor-price-table__features-list {
			--e-price-table-features-list-color: var(--e-global-color-text);
		}

		.elementor-widget-price-table .elementor-price-table__features-list li {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-price-table .elementor-price-table__features-list li:before {
			border-top-color: var(--e-global-color-text);
		}

		.elementor-widget-price-table .elementor-price-table__button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-price-table .elementor-price-table__additional_info {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-price-table .elementor-price-table__ribbon-inner {
			background-color: var(--e-global-color-accent);
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-flip-box .elementor-flip-box__front .elementor-flip-box__layer__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-flip-box .elementor-flip-box__front .elementor-flip-box__layer__description {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-flip-box .elementor-flip-box__back .elementor-flip-box__layer__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-flip-box .elementor-flip-box__back .elementor-flip-box__layer__description {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-flip-box .elementor-flip-box__button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-call-to-action .elementor-cta__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-call-to-action .elementor-cta__description {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-call-to-action .elementor-cta__button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-call-to-action .elementor-ribbon-inner {
			background-color: var(--e-global-color-accent);
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-media-carousel .elementor-carousel-image-overlay {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-testimonial-carousel .elementor-testimonial__text {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-testimonial-carousel .elementor-testimonial__name {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-testimonial-carousel .elementor-testimonial__title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-reviews .elementor-testimonial__header,
		.elementor-widget-reviews .elementor-testimonial__name {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-reviews .elementor-testimonial__text {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-table-of-contents {
			--header-color: var(--e-global-color-secondary);
			--item-text-color: var(--e-global-color-text);
			--item-text-hover-color: var(--e-global-color-accent);
			--marker-color: var(--e-global-color-text);
		}

		.elementor-widget-table-of-contents .elementor-toc__header,
		.elementor-widget-table-of-contents .elementor-toc__header-title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-table-of-contents .elementor-toc__list-item {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-countdown .elementor-countdown-item {
			background-color: var(--e-global-color-primary);
		}

		.elementor-widget-countdown .elementor-countdown-digits {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-countdown .elementor-countdown-label {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-countdown .elementor-countdown-expire--message {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-search-form input[type="search"].elementor-search-form__input {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-search-form .elementor-search-form__input,
		.elementor-widget-search-form .elementor-search-form__icon,
		.elementor-widget-search-form .elementor-lightbox .dialog-lightbox-close-button,
		.elementor-widget-search-form .elementor-lightbox .dialog-lightbox-close-button:hover,
		.elementor-widget-search-form.elementor-search-form--skin-full_screen input[type="search"].elementor-search-form__input {
			color: var(--e-global-color-text);
			fill: var(--e-global-color-text);
		}

		.elementor-widget-search-form .elementor-search-form__submit {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
			background-color: var(--e-global-color-secondary);
		}

		.elementor-widget-author-box .elementor-author-box__name {
			color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-author-box .elementor-author-box__bio {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-author-box .elementor-author-box__button {
			color: var(--e-global-color-secondary);
			border-color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-author-box .elementor-author-box__button:hover {
			border-color: var(--e-global-color-secondary);
			color: var(--e-global-color-secondary);
		}

		.elementor-widget-post-navigation span.post-navigation__prev--label {
			color: var(--e-global-color-text);
		}

		.elementor-widget-post-navigation span.post-navigation__next--label {
			color: var(--e-global-color-text);
		}

		.elementor-widget-post-navigation span.post-navigation__prev--label,
		.elementor-widget-post-navigation span.post-navigation__next--label {
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-post-navigation span.post-navigation__prev--title,
		.elementor-widget-post-navigation span.post-navigation__next--title {
			color: var(--e-global-color-secondary);
			font-family: var(--e-global-typography-secondary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-secondary-font-weight);
		}

		.elementor-widget-post-info .elementor-icon-list-item:not(:last-child):after {
			border-color: var(--e-global-color-text);
		}

		.elementor-widget-post-info .elementor-icon-list-icon i {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-post-info .elementor-icon-list-icon svg {
			fill: var(--e-global-color-primary);
		}

		.elementor-widget-post-info .elementor-icon-list-text,
		.elementor-widget-post-info .elementor-icon-list-text a {
			color: var(--e-global-color-secondary);
		}

		.elementor-widget-post-info .elementor-icon-list-item {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-sitemap .elementor-sitemap-title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-sitemap .elementor-sitemap-item,
		.elementor-widget-sitemap span.elementor-sitemap-list,
		.elementor-widget-sitemap .elementor-sitemap-item a {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-sitemap .elementor-sitemap-item {
			color: var(--e-global-color-text);
		}

		.elementor-widget-blockquote .elementor-blockquote__content {
			color: var(--e-global-color-text);
		}

		.elementor-widget-blockquote .elementor-blockquote__author {
			color: var(--e-global-color-secondary);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .woocommerce-loop-product__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .woocommerce-loop-product__title,
		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .price {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .price ins {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .price ins .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .price del {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .price del .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .price del {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products ul.products li.product .button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-wc-archive-products.elementor-wc-products .added_to_cart {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-wc-archive-products {
			--products-title-color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-archive-products.products-heading-show .related-products>h2,
		.elementor-widget-wc-archive-products.products-heading-show .upsells>h2,
		.elementor-widget-wc-archive-products.products-heading-show .cross-sells>h2 {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-wc-archive-products .elementor-products-nothing-found {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .woocommerce-loop-product__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .woocommerce-loop-product__title,
		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .price {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .price ins {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .price ins .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .price del {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .price del .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .price del {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products ul.products li.product .button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-woocommerce-archive-products.elementor-wc-products .added_to_cart {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-woocommerce-archive-products {
			--products-title-color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-archive-products.products-heading-show .related-products>h2,
		.elementor-widget-woocommerce-archive-products.products-heading-show .upsells>h2,
		.elementor-widget-woocommerce-archive-products.products-heading-show .cross-sells>h2 {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-archive-products .elementor-products-nothing-found {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .woocommerce-loop-product__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .woocommerce-loop-product__title,
		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .price {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .price ins {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .price ins .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .price del {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .price del .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .price del {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products ul.products li.product .button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-woocommerce-products.elementor-wc-products .added_to_cart {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-woocommerce-products {
			--products-title-color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-products.products-heading-show .related-products>h2,
		.elementor-widget-woocommerce-products.products-heading-show .upsells>h2,
		.elementor-widget-woocommerce-products.products-heading-show .cross-sells>h2 {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .woocommerce-loop-product__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .woocommerce-loop-product__title,
		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .price {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .price ins {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .price ins .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .price del {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .price del .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .price del {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-wc-products.elementor-wc-products ul.products li.product .button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-wc-products.elementor-wc-products .added_to_cart {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-wc-add-to-cart .elementor-button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-wc-categories .woocommerce .woocommerce-loop-category__title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-wc-categories .woocommerce-loop-category__title .count {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-menu-cart .elementor-menu-cart__toggle .elementor-button {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-menu-cart .elementor-menu-cart__product-name a {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-menu-cart .elementor-menu-cart__product-price {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-menu-cart .elementor-menu-cart__footer-buttons .elementor-button {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-menu-cart .elementor-menu-cart__footer-buttons a.elementor-button--view-cart {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-menu-cart .elementor-menu-cart__footer-buttons a.elementor-button--checkout {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-menu-cart .woocommerce-mini-cart__empty-message {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-product-title .elementor-heading-title {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.woocommerce .elementor-widget-woocommerce-product-price .price {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-product-meta .product_meta .detail-container:not(:last-child):after {
			border-color: var(--e-global-color-text);
		}

		.elementor-widget-woocommerce-product-content {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .woocommerce-loop-product__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .woocommerce-loop-product__title,
		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .price {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .price ins {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .price ins .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .price del {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .price del .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .price del {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products ul.products li.product .button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-woocommerce-product-related.elementor-wc-products .added_to_cart {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.woocommerce .elementor-widget-woocommerce-product-related.elementor-wc-products .products>h2 {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .woocommerce-loop-product__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .woocommerce-loop-product__title,
		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .woocommerce-loop-category__title {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .price {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .price ins {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .price ins .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .price del {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .price del .amount {
			color: var(--e-global-color-primary);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .price del {
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products ul.products li.product .button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products .added_to_cart {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-woocommerce-product-upsell.elementor-wc-products .products>h2 {
			color: var(--e-global-color-primary);
			font-family: var(--e-global-typography-primary-font-family), Sans-serif;
			font-weight: var(--e-global-typography-primary-font-weight);
		}

		.elementor-widget-woocommerce-checkout-page .product-name .variation {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-lottie {
			--caption-color: var(--e-global-color-text);
		}

		.elementor-widget-lottie .e-lottie__caption {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-video-playlist .e-tabs-header .e-tabs-title {
			color: var(--e-global-color-text);
		}

		.elementor-widget-video-playlist .e-tabs-header .e-tabs-videos-count {
			color: var(--e-global-color-text);
		}

		.elementor-widget-video-playlist .e-tabs-header .e-tabs-header-right-side i {
			color: var(--e-global-color-text);
		}

		.elementor-widget-video-playlist .e-tabs-header .e-tabs-header-right-side svg {
			fill: var(--e-global-color-text);
		}

		.elementor-widget-video-playlist .e-tab-title .e-tab-title-text {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-video-playlist .e-tab-title .e-tab-title-text a {
			color: var(--e-global-color-text);
		}

		.elementor-widget-video-playlist .e-tab-title .e-tab-duration {
			color: var(--e-global-color-text);
		}

		.elementor-widget-video-playlist .e-tabs-items-wrapper .e-tab-title:where(.e-active, :hover) .e-tab-title-text {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-video-playlist .e-tabs-items-wrapper .e-tab-title:where(.e-active, :hover) .e-tab-title-text a {
			color: var(--e-global-color-text);
		}

		.elementor-widget-video-playlist .e-tabs-items-wrapper .e-tab-title:where(.e-active, :hover) .e-tab-duration {
			color: var(--e-global-color-text);
		}

		.elementor-widget-video-playlist .e-tabs-items-wrapper .e-section-title {
			color: var(--e-global-color-text);
		}

		.elementor-widget-video-playlist .e-tabs-inner-tabs .e-inner-tabs-wrapper .e-inner-tab-title a {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-video-playlist .e-tabs-inner-tabs .e-inner-tabs-content-wrapper .e-inner-tab-content .e-inner-tab-text {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-video-playlist .e-tabs-inner-tabs .e-inner-tabs-content-wrapper .e-inner-tab-content button {
			color: var(--e-global-color-text);
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
		}

		.elementor-widget-video-playlist .e-tabs-inner-tabs .e-inner-tabs-content-wrapper .e-inner-tab-content button:hover {
			color: var(--e-global-color-text);
		}

		.elementor-widget-paypal-button .elementor-button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-paypal-button .elementor-message {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-stripe-button .elementor-button {
			font-family: var(--e-global-typography-accent-font-family), Sans-serif;
			font-weight: var(--e-global-typography-accent-font-weight);
			background-color: var(--e-global-color-accent);
		}

		.elementor-widget-stripe-button .elementor-message {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}

		.elementor-widget-progress-tracker .current-progress-percentage {
			font-family: var(--e-global-typography-text-font-family), Sans-serif;
			font-weight: var(--e-global-typography-text-font-weight);
		}
	</style>
	<link rel="stylesheet" id="swiper-css"
		href="<?php echo e(asset('frontend/plugins/elementor/assets/lib/swiper/css/swiper.min48f5.css?ver=5.3.6')); ?>" type="text/css"
		media="all">
	<link rel="stylesheet" id="elementor-pro-css"
		href="<?php echo e(asset('frontend/plugins/elementor-pro/assets/css/frontend-lite.min3430.css?ver=3.7.5')); ?>" type="text/css"
		media="all">
	<link rel="stylesheet" id="font-awesome-5-all-css"
		href="<?php echo e(asset('frontend/plugins/elementor/assets/lib/font-awesome/css/all.min8864.css?ver=3.17.3')); ?>" type="text/css"
		media="all">
	<link rel="stylesheet" id="font-awesome-4-shim-css"
		href="<?php echo e(asset('frontend/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min8864.css?ver=3.17.3')); ?>" type="text/css"
		media="all">
	<link rel="stylesheet" id="google-fonts-1-css"
		href="https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=auto&amp;ver=6.4.3"
		type="text/css" media="all">
	<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
	<script type="text/javascript" id="jquery-core-js-extra">
		/* <![CDATA[ */
		var moko_data = { "ajaxurl": "https:\/\/wp.themerange.net\/moko\/wp-admin\/admin-ajax.php", "nonce": "e0b198f7be" };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/js/jquery/jquery.minf43b.js?ver=3.7.1')); ?>" id="jquery-core-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend//js/jquery/jquery-migrate.min5589.js?ver=3.4.1')); ?>"
		id="jquery-migrate-js"></script>
	<script type="text/javascript"
		src="<?php echo e(asset('frontend/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.mine58f.js?ver=2.7.0-wc.8.3.0')); ?>"
		id="jquery-blockui-js" defer="defer" data-wp-strategy="defer"></script>
	<script type="text/javascript" id="wc-add-to-cart-js-extra">
		/* <![CDATA[ */
		var wc_add_to_cart_params = { "ajax_url": "\/moko\/wp-admin\/admin-ajax.php", "wc_ajax_url": "\/moko\/?wc-ajax=%%endpoint%%&elementor_page_id=14", "i18n_view_cart": "View cart", "cart_url": "https:\/\/wp.themerange.net\/moko\/cart\/", "is_cart": "", "cart_redirect_after_add": "no" };
		/* ]]> */
	</script>
	<script type="text/javascript"
		src="<?php echo e(asset('frontend/plugins/woocommerce/assets/js/frontend/add-to-cart.min9662.js?ver=8.3.0" id="wc-add-to-cart-js')); ?>"
		defer="defer" data-wp-strategy="defer"></script>
	<script type="text/javascript"
		src="<?php echo e(asset('frontend/plugins/woocommerce/assets/js/js-cookie/js.cookie.min1e55.js?ver=2.1.4-wc.8.3.0')); ?>"
		id="js-cookie-js" defer="defer" data-wp-strategy="defer"></script>
	<script type="text/javascript" id="woocommerce-js-extra">
		/* <![CDATA[ */
		var woocommerce_params = { "ajax_url": "\/moko\/wp-admin\/admin-ajax.php", "wc_ajax_url": "\/moko\/?wc-ajax=%%endpoint%%&elementor_page_id=14" };
		/* ]]> */
	</script>
	<script type="text/javascript"
		src="<?php echo e(asset('frontend/plugins/woocommerce/assets/js/frontend/woocommerce.min9662.js?ver=8.3.0')); ?>" id="woocommerce-js"
		defer="defer" data-wp-strategy="defer"></script>
	<script type="text/javascript"
		src="<?php echo e(asset('frontend/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min8864.js?ver=3.17.3')); ?>"
		id="font-awesome-4-shim-js"></script>
	<link rel="https://api.w.org/" href="wp-json/index.html">
	<link rel="alternate" type="application/json" href="wp-json/wp/v2/pages/14.json">
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://127.0.0.1/?rsd">
	<meta name="generator" content="WordPress 6.4.3">
	<meta name="generator" content="WooCommerce 8.3.0">
	<link rel="canonical" href="index.html">
	<link rel="shortlink" href="index.html">
	<link rel="alternate" type="application/json+oembed"
		href="wp-json/oembed/1.0/embedb79a.json?url=https%3A%2F%2Fwp.themerange.net%2Fmoko%2F">
	<link rel="alternate" type="text/xml+oembed"
		href="wp-json/oembed/1.0/embed32c2?url=https%3A%2F%2Fwp.themerange.net%2Fmoko%2F&amp;format=xml">
	<noscript>
		<style>
			.woocommerce-product-gallery {
				opacity: 1 !important;
			}
		</style>
	</noscript>
	<meta name="generator"
		content="Elementor 3.17.3; features: e_dom_optimization, e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints; settings: css_print_method-internal, google_font-enabled, font_display-auto">
</head>

<body
	class="home page-template page-template-tpl-default-elementor page-template-tpl-default-elementor-php page page-id-14 theme-moko woocommerce-no-js menu-layer elementor-default elementor-kit-6 elementor-page elementor-page-14">
	<div class="">
		<div class="page-wrapper hidden-bar-wrapper   ">
			<!-- Main Header-->
			<header class="main-header header-style-one">
				<!--Header-Upper-->
				<div class="header-upper">
					<div class="auto-container clearfix">
						<div class="pull-left logo-box">
							<div class="logo">
								<a href="index.html" title="Moko">
									<img src="<?php echo e(asset('frontend/uploads/2021/11/adworld.png')); ?>" alt="logo"
										style="width:150px; height:70px;">
								</a>
							</div>
						</div>
						<div class="nav-outer clearfix">
							<!--Mobile Navigation Toggler-->
							<div class="mobile-nav-toggler">
								<span class="icon flaticon-menu"></span>
							</div>
							<!-- Main Menu -->
							<nav class="main-menu navbar-expand-md">
								<div class="navbar-header">
									<!-- Toggle Button -->
									<button class="navbar-toggler" type="button" data-toggle="collapse"
										data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
										aria-expanded="false" aria-label="Toggle navigation">
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
								</div>
								<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
									<ul class="navigation clearfix">
										<li id="menu-item-170"
											class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-170 dropdown  <?php echo $__env->yieldContent('home'); ?> ">
											<a title="Home" href="/" data-toggle="dropdown1"
												class="hvr-underline-from-left1" aria-expanded="false" data-scroll
												data-options="easing: easeOutQuart">Home</a>
										</li>
										<li id="menu-item-453"
											class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-453 dropdown <?php echo $__env->yieldContent('about'); ?>">
											<a title="About Us" href="/about" data-toggle="dropdown1"
												class="hvr-underline-from-left1" aria-expanded="false" data-scroll
												data-options="easing: easeOutQuart">About Us</a>

										</li>
										<li id="menu-item-532"
											class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-532 dropdown <?php echo $__env->yieldContent('serveice'); ?>">
											<a title="Services" href="/service" data-toggle="dropdown1"
												class="hvr-underline-from-left1" aria-expanded="false" data-scroll
												data-options="easing: easeOutQuart">Services</a>

										</li>

										<li id="menu-item-603"
											class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-603 dropdown <?php echo $__env->yieldContent('achievements'); ?>">
											<a title="Shop" href="/achievements" data-toggle="dropdown1"
												class="hvr-underline-from-left1" aria-expanded="false" data-scroll
												data-options="easing: easeOutQuart">Achievements</a>

										</li>

										<li id="menu-item-453"
											class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-453 dropdown <?php echo $__env->yieldContent('demo'); ?>">
											<a title="Demo" href="/awards" data-toggle="dropdown1"
												class="hvr-underline-from-left1" aria-expanded="false" data-scroll
												data-options="easing: easeOutQuart">Awards</a>

										</li>

										<li id="menu-item-608"
											class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-608 dropdown <?php echo $__env->yieldContent('gallery'); ?>">
											<a title="Blog" href="/gallery" data-toggle="dropdown1"
												class="hvr-underline-from-left1" aria-expanded="false" data-scroll
												data-options="easing: easeOutQuart">Gallery</a>

										</li>
										<li id="menu-item-611"
											class="menu-item menu-item-type-post_type menu-item-object-page menu-item-611 <?php echo $__env->yieldContent('contact'); ?>">
											<a title="Contact Us" href="/contact"
												class="hvr-underline-from-left1" data-scroll
												data-options="easing: easeOutQuart">Contact Us</a>
										</li>
									</ul>
								</div>
							</nav>
							<!-- Main Menu End-->
							<div class="outer-box clearfix">
								<!-- Quote Btn -->
								<div class="btn-box">
									<a href="/contact" class="theme-btn btn-style-one">
										<span class="txt">Get A Quote</span>
									</a>
								</div>
								<!-- Search Btn -->
								
							</div>
						</div>
					</div>
				</div>
				<!--End Header Upper-->
				<!-- Sticky Header  -->
				<div class="sticky-header">
					<div class="auto-container clearfix">
						<!--Logo-->
						<div class="logo pull-left">
							<a href="#" title="Moko">
								<img src="<?php echo e(asset('frontend/uploads/2021/11/adworld.png')); ?>" alt="logo"
									style=" width:130px; height:70px;">
							</a>
						</div>
						<!--Right Col-->
						<div class="pull-right">
							<!-- Main Menu -->
							<nav class="main-menu">
								<!--Keep This Empty / Menu will come through Javascript-->
							</nav>
							<!-- Main Menu End-->
							<!-- Main Menu End-->
							<div class="outer-box clearfix">
								<div class="mobile-nav-toggler">
									<span class="icon flaticon-menu"></span>
								</div>
								<!-- Quote Btn -->
								<div class="btn-box">
									<a href="#" class="theme-btn btn-style-two">
										<span class="txt">Get A Quote</span>
									</a>
								</div>
								<!-- Search Btn -->
								
							</div>
						</div>
					</div>
				</div>
				<!-- End Sticky Menu -->
				<!-- Mobile Menu  -->
				<div class="mobile-menu">
					<div class="menu-backdrop"></div>
					<div class="close-btn">
						<span class="icon flaticon-multiply"></span>
					</div>
					<nav class="menu-box">
						<div class="nav-logo">
							<a href="index.html" title="Moko">
								<img src="<?php echo e(asset('frontend/uploads/2021/11/adworld.png')); ?>" alt="logo"
									style=" width:130px; height:70px;">
							</a>
						</div>
						<div class="menu-outer">
							<!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
						</div>
					</nav>
				</div>
				<!-- End Mobile Menu -->
			</header>
			<!-- End Main Header -->

            <?php echo $__env->yieldContent('body'); ?>


			<!-- Main Footer -->
			<footer class="main-footer style-three">
				<div class="pattern-layer"
					style="background-image: url(<?php echo e(asset('frontend/themes/moko/assets/images/background/pattern-3.png)')); ?>"></div>
				<div class="pattern-layer-two"
					style="background-image: url(<?php echo e(asset('frontend/themes/moko/assets/images/background/pattern-4.png)')); ?>"></div>
				<div class="pattern-layer-three"
					style="background-image: url(<?php echo e(asset('frontend/themes/moko/assets/images/background/pattern-5.png)')); ?>"></div>
				<div class="auto-container">
					<!--Widgets Section-->
					<div class="widgets-section">
						<div class="row clearfix">
							<div class="footer-column col-lg-3 col-md-6 col-sm-12">
								<div id="moko_about_company_v1-2" class="footer-widget widget_moko_about_company_v1">
									<div class="logo-widget">
										<div class="logo">
											<a href="#">
												<img src="uploads/2021/11/adworld.png" alt="">
											</a>
										</div>
										<div class="text">Adworld Advertising is a pioneering Indian
											advertising agency established in 2002, headquartered in
											Trivandrum, Kerala.
										</div>
										<!-- Social Box -->
										<ul class="social-box">
											<li>
												<a href="https://www.facebook.com/"
													style="background-color:rgba(0, 0, 0, 0); color: rgb(255, 255, 255)">
													<i class="fab fa-facebook-f"></i>
												</a>
											</li>
											<li>
												<a href="https://www.linkedin.com/"
													style="background-color:rgba(0, 0, 0, 0); color: rgb(255, 255, 255)">
													<i class="fab fa-linkedin"></i>
												</a>
											</li>
											<li>
												<a href="https://www.twitter.com/"
													style="background-color:rgba(0, 0, 0, 0); color: rgb(255, 255, 255)">
													<i class="fab fa-twitter"></i>
												</a>
											</li>
											<li>
												<a href="https://www.youtube.com/"
													style="background-color:rgba(0, 0, 0, 0); color: rgb(255, 255, 255)">
													<i class="fab fa-youtube"></i>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="footer-column col-lg-3 col-md-6 col-sm-12">
								<div id="nav_menu-2" class="footer-widget widget_nav_menu">
									<h4>Services</h4>
									<div class="menu-services-footer-container">
										<ul id="menu-services-footer" class="menu">
											<li id="menu-item-952"
												class="menu-item menu-item-type-post_type menu-item-object-page menu-item-952">
												<a href="/service">Strategic Advertising Campaigns</a>
											</li>
											<li id="menu-item-953"
												class="menu-item menu-item-type-post_type menu-item-object-page menu-item-953">
												<a href="/service">Creative Design</a>
											</li>
											<li id="menu-item-951"
												class="menu-item menu-item-type-post_type menu-item-object-page menu-item-951">
												<a href="/service">Media Planning & Buying</a>
											</li>
											<li id="menu-item-954"
												class="menu-item menu-item-type-post_type menu-item-object-page menu-item-954">
												<a href="/service">Marketing</a>
											</li>
											<li id="menu-item-955"
												class="menu-item menu-item-type-post_type menu-item-object-page menu-item-955">
												<a href="/service">Audio & Visual Advertising</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="footer-column col-lg-3 col-md-6 col-sm-12">
								<div id="moko_gallery_v1-2" class="footer-widget widget_moko_gallery_v1">
									<!--Footer Column-->
									<div class="gallery-widget">
										<h4>Gallery</h4>
										<div class="widget-content">
											<div class="images-outer clearfix">
												<!--Image Box-->
                                                <?php
                                                    use App\Models\gallery;
                                                    $gallery = gallery::take(6)->get();
                                                ?>
                                                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <figure class="image-box">
													<a href="<?php echo e($img->image); ?>"
														data-fancybox="footer-gallery" title="Movie Recommendation">
														<img width="80" height="80"
															src="<?php echo e($img->image); ?>"
                                                            style="height: 65px;"
															class="attachment-moko_80x80 size-moko_80x80 wp-post-image"
															alt="" decoding="async" loading="lazy"
															srcset="<?php echo e($img->image); ?>"
															sizes="(max-width: 80px) 100vw, 80px">
													</a>
												</figure>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<!--Image Box-->

											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="footer-column col-lg-3 col-md-6 col-sm-12">
								<div id="moko_contact_info_v1-2" class="footer-widget widget_moko_contact_info_v1">
									<div class="links-widget">
										<h4>Contact Info</h4>
										<ul class="list-style-two">
											<li>
												<span class="icon flaticon-wall-clock"></span>Mon – Sat 10:00pm - 8:00pm
											</li>
											<li>
												<span class="icon flaticon-phone-call"></span>
												<a href="tel:0987654321">+ 91 94470 29708,</a><br>
												<a href="tel:0123456789">+91 79944 27707</a>
											</li>
											<li>
												<span class="icon flaticon-email"></span>
												<a href="mailto:adworldtvm@gmail.com">adworldtvm@gmail.com,</a>
												<a href="mailto:creativeedgedubai@gmail.comt">creativeedgedubai@gmail.com</a>

											</li>
											<li>
												<span class="icon flaticon-maps-and-flags"></span><a href="/contact"><b>India, Dubai </b></a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Footer Bottom -->
					<div class="footer-bottom">
						<div class="copyright">Copyright &copy; 2024. All Rights Reserved By
							<a href="#">effects world.</a>
						</div>
					</div>
				</div>
			</footer>
			<!-- End Main Footer -->
		</div>
	</div>
	<!-- End Page Wrapper -->
	<!-- Search Popup -->
	<div class="search-popup">
		<button class="close-search style-two">
			<span class="flaticon-multiply"></span>
		</button>
		<button class="close-search">
			<span class="fa fa-arrow-up"></span>
		</button>
		<form method="post" action="#">
			<div class="form-group">
				<input type="search" name="s" value="" placeholder="Search Here">
				<button type="submit">
					<i class="fa fa-search"></i>
				</button>
			</div>
		</form>
	</div>
	<!-- End Header Search -->
	<!-- Scroll To Top -->
	<div class="back-to-top scroll-to-target show-back-to-top" data-target="html">TOP</div>
	<!-- Color Palate / Color Switcher -->

	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$('form.cart').on('click', 'button.plus, button.minus', function () {
				// Get current quantity values
				var qty = $(this).closest('form.cart').find('.qty');
				var val = parseFloat(qty.val());
				var max = parseFloat(qty.attr('max'));
				var min = parseFloat(qty.attr('min'));
				var step = parseFloat(qty.attr('step'));

				// Change the value if plus or minus
				if ($(this).is('.plus')) {
					if (max && (max <= val)) {
						qty.val(max);
					}
					else {
						qty.val(val + step);
					}
				} else {
					if (min && (min >= val)) {
						qty.val(min);
					}
					else if (val > 1) {
						qty.val(val - step);
					}
				}
			});
		});
	</script>
	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/plugins/contact-form-7/includes/swv/js/index69c8.js?ver=5.8.4')); ?>"
		id="swv-js"></script>
	<script type="text/javascript" id="contact-form-7-js-extra">
		/* <![CDATA[ */
		var wpcf7 = { "api": { "root": "https:\/\/wp.themerange.net\/moko\/wp-json\/", "namespace": "contact-form-7\/v1" } };
		/* ]]> */
	</script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/plugins/contact-form-7/includes/js/index69c8.js?ver=5.8.4')); ?>"
		id="contact-form-7-js"></script>
	<script type="text/javascript" src="wp-includes/js/jquery/ui/core.min3f14.js?ver=1.13.2"
		id="jquery-ui-core-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/popper.min431f.js?ver=2.1.2')); ?>"
		id="popper-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/bootstrap.min431f.js?ver=2.1.2')); ?>"
		id="bootstrap-js"></script>
	<script type="text/javascript"
		src="<?php echo e(asset('frontend/themes/moko/assets/js/jquery.mCustomScrollbar.concat.min431f.js?ver=2.1.2')); ?>"
		id="mCustomScrollbar-concat-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/jquery.fancybox431f.js?ver=2.1.2')); ?>"
		id="fancybox-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/appear431f.js?ver=2.1.2')); ?>"
		id="appear-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/parallax.min431f.js?ver=2.1.2')); ?>"
		id="parallax-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/tilt.jquery.min431f.js?ver=2.1.2')); ?>"
		id="tilt-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/jquery.paroller.min431f.js?ver=2.1.2')); ?>"
		id="paroller-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/owl431f.js?ver=2.1.2')); ?>" id="owl-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/wow431f.js?ver=2.1.2')); ?>" id="wow-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/jquery.countdown431f.js?ver=2.1.2')); ?>"
		id="countdown-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/mixitup431f.js?ver=2.1.2')); ?>"
		id="mixitup-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/nav-tool431f.js?ver=2.1.2')); ?>"
		id="nav-tool-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/pagenav431f.js?ver=2.1.2')); ?>"
		id="pagenav-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/jquery-ui431f.js?ver=2.1.2')); ?>"
		id="jquery-ui-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/themes/moko/assets/js/script84fc.js?ver=6.4.3')); ?>"
		id="moko-main-script-js"></script>
	<script type="text/javascript" src="wp-includes/js/comment-reply.min84fc.js?ver=6.4.3" id="comment-reply-js"
		async="async" data-wp-strategy="async"></script>
	<script type="text/javascript"
		src="<?php echo e(asset('frontend/plugins/elementor-pro/assets/js/webpack-pro.runtime.min3430.js?ver=3.7.5')); ?>"
		id="elementor-pro-webpack-runtime-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/plugins/elementor/assets/js/webpack.runtime.min8864.js?ver=3.17.3')); ?>"
		id="elementor-webpack-runtime-js"></script>
	<script type="text/javascript" src="<?php echo e(asset('frontend/plugins/elementor/assets/js/frontend-modules.min8864.js?ver=3.17.3')); ?>"
		id="elementor-frontend-modules-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/vendor/wp-polyfill-inert.min0226.js?ver=3.1.2"
		id="wp-polyfill-inert-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/vendor/regenerator-runtime.min6c85.js?ver=0.14.0"
		id="regenerator-runtime-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0"
		id="wp-polyfill-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/hooks.min2ebd.js?ver=c6aec9a8d4e5a5d543a1"
		id="wp-hooks-js"></script>
	<script type="text/javascript" src="wp-includes/js/dist/i18n.minf92f.js?ver=7701b0c3857f914212ef"
		id="wp-i18n-js"></script>
	<script type="text/javascript" id="wp-i18n-js-after">
		/* <![CDATA[ */
		wp.i18n.setLocaleData({ 'text direction\u0004ltr': ['ltr'] });
		/* ]]> */
	</script>
	
	<script type="text/javascript" src="<?php echo e(asset('frontend/plugins/elementor-pro/assets/js/frontend.min3430.js?ver=3.7.5')); ?>"
		id="elementor-pro-frontend-js"></script>
	<script type="text/javascript"
		src="<?php echo e(asset('frontend/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2')); ?>"
		id="elementor-waypoints-js"></script>
	
	<script type="text/javascript" src="<?php echo e(asset('frontend/plugins/elementor/assets/js/frontend.min8864.js?ver=3.17.3')); ?>"
		id="elementor-frontend-js"></script>
	<script type="text/javascript"
		src="<?php echo e(asset('frontend/plugins/elementor-pro/assets/js/elements-handlers.min3430.js?ver=3.7.5')); ?>"
		id="pro-elements-handlers-js"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\AddWorld\adworld\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>