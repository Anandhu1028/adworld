
<?php $__env->startSection('demo'); ?>
current current-menu-ancestor current-menu-parent
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>


<section class="page-title" style="background-image: url(<?php echo e(asset('frontend/uploads/2021/10/pattern-16.png')); ?>)">
   <div class="pattern-layer-one"
      style="background-image: url(<?php echo e(asset('frontend/themes/moko/assets/images/main-slider/pattern-1.png')); ?>)"></div>
   <div class="pattern-layer-two"
      style="background-image: url(<?php echo e(asset('frontend/themes/moko/assets/images/background/pattern-17.png')); ?>)"></div>
   <div class="pattern-layer-three"
      style="background-image: url(<?php echo e(asset('frontend/themes/moko/assets/images/background/pattern-18.png')); ?>)"></div>
   <div class="pattern-layer-four"
      style="background-image: url(<?php echo e(asset('frontend/themes/moko/assets/images/icons/cross-icon.png')); ?>)"></div>
   <div class="auto-container">
      <h2> Awards</h2>
      <ul class="page-breadcrumb">
         <li><a href="../index.html">Home</a></li>
         <li>Awards</li>
      </ul>
   </div>
</section>
<!-- End Page Title Section -->
<div data-elementor-type="wp-page" data-elementor-id="723" class="elementor elementor-723">
   <section
      class="elementor-section elementor-top-section elementor-element elementor-element-8bda09d elementor-section-full_width elementor-section-height-default elementor-section-height-default"
      data-id="8bda09d" data-element_type="section">
      <div class="elementor-container elementor-column-gap-default">
         <div
            class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5e38bf0"
            data-id="5e38bf0" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
               <div
                  class="elementor-element elementor-element-a7ab0c7 elementor-widget elementor-widget-moko_blog_with_sidebar"
                  data-id="a7ab0c7" data-element_type="widget" data-widget_type="moko_blog_with_sidebar.default">
                  <div class="elementor-widget-container">

                     <!-- Sidebar Page Container -->
                     <div class="sidebar-page-container">
                        <div class="auto-container">
                           <div class="row clearfix">


                              <!-- Content Side -->
                              
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img fetchpriority="high" decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-17-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../google-now-disregards-or-overlooks-all-reciprocal-links-3/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a
                                                   href="../google-now-disregards-or-overlooks-all-reciprocal-links-3/index.html">Google
                                                   now disregards or overlooks all reciprocal links</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                                       Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer
                                                        took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-18-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../absolute-links-vs-relative-links-seo-intrinsic-value-3/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a
                                                   href="../absolute-links-vs-relative-links-seo-intrinsic-value-3/index.html">Absolute
                                                   Links vs. Relative Links – SEO Intrinsic Value</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-19-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../how-to-increase-your-roi-through-scientific-sem-2/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a
                                                   href="../how-to-increase-your-roi-through-scientific-sem-2/index.html">How
                                                   to increase your ROI through scientific SEM?</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img loading="lazy" decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-20-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../the-security-risks-of-change-package-owners/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a href="../the-security-risks-of-change-package-owners/index.html">The
                                                   security risks of change package owners</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img fetchpriority="high" decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-17-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../protect-your-workplace-from-cyber-attacks/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a href="../protect-your-workplace-from-cyber-attacks/index.html">Protect
                                                   Your Workplace From Cyber Attacks</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-18-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../better-software-promotes-sales-profits/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a href="../better-software-promotes-sales-profits/index.html">Better
                                                   software promotes sales &#038; profits</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                                       Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer
                                                        took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-19-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../better-app-promotes-sales-profits/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a href="../better-app-promotes-sales-profits/index.html">Better App
                                                   promotes sales &#038; profits</a></h5>
                                                   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio totam
                                                       cupiditate quibusdam, hic facere maiores cumque impedit placeat, aperiam animi iure deserunt nisi minus 
                                                       aut asperiores veniam nam esse repellendus?</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img loading="lazy" decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontendt/uploads/2021/11/news-20-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../best-reseller-hosting-for-start-business/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a href="../best-reseller-hosting-for-start-business/index.html">Best
                                                   reseller hosting for start business</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy 
                                                      text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img fetchpriority="high" decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-17-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../security-risks-of-chang-package-owners/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a href="../security-risks-of-chang-package-owners/index.html">Security
                                                   Risks of Chang Package Owners</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                                       Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer
                                                        took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-18-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../corporate-workflow-make-a-diffrence/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a href="../corporate-workflow-make-a-diffrence/index.html">Corporate
                                                   Workflow make a diffrence</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                                                       when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-19-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../a-guide-to-google-seo-algorithm-updates/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a href="../a-guide-to-google-seo-algorithm-updates/index.html">A Guide
                                                   to Google SEO Algorithm Updates</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                                                       when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- News Block -->
                                    <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                       <div class="inner-box wow fadeInLeft" data-wow-delay="0ms"
                                          data-wow-duration="1500ms">
                                          <div class="image">
                                             <img loading="lazy" decoding="async" width="370" height="250"
                                                src="<?php echo e(asset('frontend/uploads/2021/11/news-20-370x250.jpg')); ?>"
                                                class="attachment-moko_370x250 size-moko_370x250 wp-post-image"
                                                alt="" /> <!-- Overlay Box -->
                                             <div class="overlay-box">
                                                <div class="overlay-inner">
                                                   <div class="content">
                                                      <a href="../best-and-fastest-data-server-ever-here/index.html"
                                                         class="icon flaticon-unlink"></a>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="lower-content">
                                             
                                             <h5><a href="../best-and-fastest-data-server-ever-here/index.html">Best and
                                                   fastest data server ever here</a></h5>
                                                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                                       Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                                                        when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>

                                 <!-- Post Share Options -->
                                 <div class="styled-pagination text-center">
                                    <ul class="pagination">
                                       <li><span aria-current="page" class="page-numbers current">1</span></li>
                                       <li><a class="page-numbers" href="page/2/index.html">2</a></li>
                                       <li><a class="next page-numbers" href="page/2/index.html"><i
                                                class="fa fa-angle-right"></i></a></li>
                                    </ul>
                                 </div>
                              </div>

                              <!-- Sidebar Side -->
                              

                           </div>
                        </div>
                     </div>

                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>

<div class="clearfix"></div>



</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AddWorld\adworld\resources\views/frontend/demo.blade.php ENDPATH**/ ?>