<?php $__env->startSection('body'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<div class="px-2 py-3 ps-md-4 pe-md-3 page-body">
    <div class="row g-0">
        <div class="col-12">
            <div class="mb-3 card">
                <div class="card-header">
                    <h6 class="m-0">Home</h6>
                    <div class="form-check form-switch table-toggle-one">
                        <a href="" class="btn btn-primary">Contents</a>
                        

                    </div>
                </div>
                <div class="card-body table-main-one">
                    <div class="table-responsive">
                        <table class="table mb-0 align-middle myDataTable table-hover" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$achivement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index+1); ?></td>
                                        <td><?php echo e($achivement->type); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('achievement_show',['id'=>$achivement->id])); ?>" class="btn btn-warning">Open</a>
                                            <a href="<?php echo e(route('achievement_all_delete',['id'=>$achivement->id])); ?>" onclick="return confirm('Are you sure you want to delete this item?')" class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <form action="<?php echo e(route('achievement_store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <td></td>
                                        <td><div class="w-50">
                                            <span class="">
                                                <input type="text" class="form-control" id="TextInput" placeholder="Name" name="name" required>
                                            </span>
                                        </div></td>
                                        <td><button type="submit" class="btn btn-primary">Add</button></td>
                                    </form>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AddWorld\adworld\resources\views/admin/achivementes/index.blade.php ENDPATH**/ ?>