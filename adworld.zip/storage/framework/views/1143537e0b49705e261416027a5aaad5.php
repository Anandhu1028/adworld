<?php $__env->startSection('gallery'); ?>
current current-menu-ancestor current-menu-parent
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<section class="page-title" style="background-image: url(<?php echo e(asset('frontend/uploads/2021/10/pattern-16.png')); ?>)">
   <div class="pattern-layer-one" style="background-image: url(<?php echo e(asset('frontend//themes/moko/assets/images/main-slider/pattern-1.png')); ?>)"></div>
   <div class="pattern-layer-two" style="background-image: url(<?php echo e(asset('frontend//themes/moko/assets/images/background/pattern-17.png')); ?>)"></div>
   <div class="pattern-layer-three" style="background-image: url(<?php echo e(asset('frontend//themes/moko/assets/images/background/pattern-18.png')); ?>)"></div>
   <div class="pattern-layer-four" style="background-image: url(<?php echo e(asset('frontend//themes/moko/assets/images/icons/cross-icon.png')); ?>)"></div>
   <div class="auto-container">
      <h2>  Our Projects</h2>
      <ul class="page-breadcrumb">
         <li><a href="../index.html">Home</a></li>
         <li>Our Projects</li>
      </ul>
   </div>
</section>
<!-- End Page Title Section -->
<div data-elementor-type="wp-page" data-elementor-id="594" class="elementor elementor-594">
   <section class="elementor-section elementor-top-section elementor-element elementor-element-939b65e elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="939b65e" data-element_type="section">
      <div class="elementor-container elementor-column-gap-default">
         <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a6fc571" data-id="a6fc571" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
               <div class="elementor-element elementor-element-e4a52c5 elementor-widget elementor-widget-moko_recent_projects" data-id="e4a52c5" data-element_type="widget" data-widget_type="moko_recent_projects.default">
                  <div class="elementor-widget-container">
                     <!-- Gallery Section -->
                     <section class="gallery-section">
                        
                        <div class="auto-container">
                           <!-- MixitUp Galery -->
                           <div class="mixitup-gallery">
                              
                              <div class="filter-list row clearfix">
                                <!--Gallery Block -->

                                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="gallery-block all mix col-lg-4 col-md-6 col-sm-12 development media optimization ">
                                    <div class="inner-box">
                                        <!--Image Box-->
									    <figure class="image-box">
											<a href="<?php echo e($image->image); ?>"
												data-fancybox="footer-gallery" title="Movie Recommendation">
												<img width="80" height="80"
												src="<?php echo e($image->image); ?>"
                                                style="height: 280px;"
												class="attachment-moko_80x80 size-moko_80x80 wp-post-image"
												alt="" decoding="async" loading="lazy"
												srcset="<?php echo e($image->image); ?>"
												sizes="(max-width: 80px) 100vw, 80px">
											</a>
										</figure>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              </div>
                              <div class="styled-pagination text-center"><br />
                              </div>
                           </div>
                        </div>
                     </section>
                     <!-- End Gallery Section -->
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>

</div>
<div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AddWorld\adworld\resources\views/frontend/gallery.blade.php ENDPATH**/ ?>