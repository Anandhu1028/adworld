

<img src="<?php echo e(asset('frontend/uploads/2021/11/adworld.png')); ?>" alt="logo"
									style=" width:130px; height:70px;">
<?php /**PATH C:\xampp\htdocs\AddWorld\adworld\resources\views/components/application-logo.blade.php ENDPATH**/ ?>